#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#include <linux/genetlink.h>
#include <linux/netlink.h>
#include <linux/nl80211.h>
#include <net/if.h>
#include <netlink/attr.h>
#include <netlink/genl/ctrl.h>
#include <netlink/genl/genl.h>
#include <netlink/handlers.h>
#include <netlink/msg.h>
#include <netlink/netlink.h>
#include <netlink/socket.h>

#define MAX_RESULTS 256

struct wifi_data {
    int frequency;
    int channel;
    int channel_width_mhz;
    char band[8];
    char bssid[20];
    char ssid[33];
    int mbm;
    int signal_dbm;
    int signal_quality;
    int connected;
    char security[64];
    char phy_mode[32];
    int max_phy_rate_mbps;
    int channel_utilization;
    int seen_ms_ago;
    char vendor[64];
};

static struct wifi_data dataResult[MAX_RESULTS];
static int result_count = 0;

struct trigger_results {
    int done;
    int aborted;
};

static int error_handler(struct sockaddr_nl *nla, struct nlmsgerr *err, void *arg) {
    int *ret = arg;
    *ret = err->error;
    fprintf(stderr, "netlink error: %d\n", err->error);
    return NL_STOP;
}

static int finish_handler(struct nl_msg *msg, void *arg) {
    int *ret = arg;
    *ret = 0;
    return NL_SKIP;
}

static int ack_handler(struct nl_msg *msg, void *arg) {
    int *ret = arg;
    *ret = 0;
    return NL_STOP;
}

static int no_seq_check(struct nl_msg *msg, void *arg) {
    return NL_OK;
}

static void json_escape(const char *in, char *out, size_t out_size) {
    size_t pos = 0;
    for (size_t i = 0; in[i] != '\0' && pos + 2 < out_size; i++) {
        unsigned char c = (unsigned char)in[i];
        if (c == '"' || c == '\\') {
            if (pos + 2 >= out_size) break;
            out[pos++] = '\\';
            out[pos++] = c;
        } else if (isprint(c)) {
            out[pos++] = c;
        } else {
            out[pos++] = '?';
        }
    }
    out[pos] = '\0';
}

static void get_bssid(char *mac_addr, const unsigned char *arg) {
    sprintf(mac_addr, "%02x:%02x:%02x:%02x:%02x:%02x",
            arg[0], arg[1], arg[2], arg[3], arg[4], arg[5]);
}

static int freq_to_channel(int freq) {
    if (freq >= 2412 && freq <= 2472) return (freq - 2412) / 5 + 1;
    if (freq == 2484) return 14;
    if (freq >= 5000 && freq <= 5895) return (freq - 5000) / 5;
    if (freq >= 5955 && freq <= 7115) return (freq - 5950) / 5;
    return -1;
}

static const char *freq_to_band(int freq) {
    if (freq >= 2412 && freq <= 2484) return "2.4GHz";
    if (freq >= 5000 && freq <= 5895) return "5GHz";
    if (freq >= 5925 && freq <= 7125) return "6GHz";
    return "unknown";
}

static int signal_quality_from_dbm(int dbm) {
    if (dbm <= -90) return 0;
    if (dbm >= -30) return 100;
    return 2 * (dbm + 90);
}

static void get_vendor(char *out, size_t out_size, const char *bssid) {
    /* Small built-in OUI map. In production, prefer doing this lookup in the backend with an IEEE OUI database. */
    struct oui_entry { const char *prefix; const char *vendor; } entries[] = {
        {"60:7e:cd", "Huawei"},
        {"94:b4:0f", "Huawei"},
        {"94:57:a5", "Huawei"},
        {"e4:83:26", "Huawei"},
        {"dc:d9:16", "Huawei"},
        {"00:e0:fc", "Huawei"},
        {"ac:e2:d3", "Huawei"},
        {"b4:fb:e4", "Huawei"},
        {"f8:e9:4e", "Huawei"},
        {NULL, NULL}
    };

    for (int i = 0; entries[i].prefix != NULL; i++) {
        if (strncasecmp(bssid, entries[i].prefix, 8) == 0) {
            snprintf(out, out_size, "%s", entries[i].vendor);
            return;
        }
    }
    snprintf(out, out_size, "Unknown");
}

static void get_ssid(char *out, const unsigned char *ie, int ielen) {
    while (ielen >= 2 && ielen >= ie[1] + 2) {
        if (ie[0] == 0 && ie[1] <= 32) {
            int len = ie[1];
            const unsigned char *data = ie + 2;
            int pos = 0;
            for (int i = 0; i < len && pos < 32; i++) {
                if (isprint(data[i]) && data[i] != '\\' && data[i] != '"') out[pos++] = data[i];
                else out[pos++] = '?';
            }
            out[pos] = '\0';
            if (pos == 0) strcpy(out, "hidden");
            return;
        }
        ielen -= ie[1] + 2;
        ie += ie[1] + 2;
    }
    strcpy(out, "hidden");
}

static void parse_security(char *out, const unsigned char *ie, int ielen) {
    int has_wpa = 0;
    int has_rsn = 0;
    int has_wep_hint = 0;
    int akm_psk = 0;
    int akm_sae = 0;
    int akm_8021x = 0;

    const unsigned char *p = ie;
    int len = ielen;
    while (len >= 2 && len >= p[1] + 2) {
        int id = p[0];
        int elen = p[1];
        const unsigned char *d = p + 2;

        if (id == 0x30 && elen >= 8) { /* RSN / WPA2/WPA3 */
            has_rsn = 1;
            int pos = 2;          /* version */
            pos += 4;             /* group cipher suite */
            if (pos + 2 <= elen) {
                int pairwise_count = d[pos] | (d[pos + 1] << 8);
                pos += 2 + pairwise_count * 4;
            }
            if (pos + 2 <= elen) {
                int akm_count = d[pos] | (d[pos + 1] << 8);
                pos += 2;
                for (int i = 0; i < akm_count && pos + 4 <= elen; i++, pos += 4) {
                    if (d[pos] == 0x00 && d[pos+1] == 0x0f && d[pos+2] == 0xac) {
                        if (d[pos+3] == 1) akm_8021x = 1;
                        if (d[pos+3] == 2) akm_psk = 1;
                        if (d[pos+3] == 8) akm_sae = 1;
                    }
                }
            }
        } else if (id == 0xdd && elen >= 8 && d[0] == 0x00 && d[1] == 0x50 && d[2] == 0xf2 && d[3] == 0x01) {
            has_wpa = 1;
        } else if (id == 0x01) {
            has_wep_hint = 1;
        }

        len -= elen + 2;
        p += elen + 2;
    }

    if (has_rsn && akm_sae && akm_psk) strcpy(out, "WPA2/WPA3-Personal");
    else if (has_rsn && akm_sae) strcpy(out, "WPA3-SAE");
    else if (has_rsn && akm_psk) strcpy(out, "WPA2-PSK");
    else if (has_rsn && akm_8021x) strcpy(out, "WPA2-Enterprise");
    else if (has_rsn) strcpy(out, "WPA2");
    else if (has_wpa) strcpy(out, "WPA");
    else if (has_wep_hint) strcpy(out, "WEP/Legacy");
    else strcpy(out, "OPEN");
}

static void parse_phy_mode(char *out, size_t out_size, const unsigned char *ie, int ielen) {
    int has_ht = 0;   /* 802.11n */
    int has_vht = 0;  /* 802.11ac */
    int has_he = 0;   /* 802.11ax */
    int has_eht = 0;  /* 802.11be */

    const unsigned char *p = ie;
    int len = ielen;
    while (len >= 2 && len >= p[1] + 2) {
        int id = p[0];
        int elen = p[1];
        const unsigned char *d = p + 2;

        if (id == 45 || id == 61) has_ht = 1;       /* HT capabilities / operation */
        if (id == 191 || id == 192) has_vht = 1;    /* VHT capabilities / operation */
        if (id == 255 && elen >= 1) {               /* Extension IE */
            if (d[0] == 35 || d[0] == 36) has_he = 1;   /* HE capabilities / operation */
            if (d[0] == 106 || d[0] == 107 || d[0] == 108) has_eht = 1; /* EHT */
        }

        len -= elen + 2;
        p += elen + 2;
    }

    if (has_eht) snprintf(out, out_size, "Wi-Fi 7 - 802.11be");
    else if (has_he) snprintf(out, out_size, "Wi-Fi 6/6E - 802.11ax");
    else if (has_vht) snprintf(out, out_size, "Wi-Fi 5 - 802.11ac");
    else if (has_ht) snprintf(out, out_size, "Wi-Fi 4 - 802.11n");
    else snprintf(out, out_size, "Legacy 802.11a/b/g");
}

static int parse_channel_utilization(const unsigned char *ie, int ielen) {
    const unsigned char *p = ie;
    int len = ielen;
    while (len >= 2 && len >= p[1] + 2) {
        if (p[0] == 11 && p[1] >= 5) { /* BSS Load element */
            int raw = p[2 + 2];        /* channel utilization byte */
            return (raw * 100) / 255;
        }
        len -= p[1] + 2;
        p += p[1] + 2;
    }
    return -1;
}

static int estimate_channel_width_mhz(const unsigned char *ie, int ielen, int freq) {
    int has_ht = 0;
    int has_vht = 0;
    int has_he = 0;

    const unsigned char *p = ie;
    int len = ielen;
    while (len >= 2 && len >= p[1] + 2) {
        int id = p[0];
        int elen = p[1];
        const unsigned char *d = p + 2;
        if (id == 45 || id == 61) has_ht = 1;
        if (id == 191 || id == 192) has_vht = 1;
        if (id == 255 && elen >= 1 && (d[0] == 35 || d[0] == 36)) has_he = 1;
        len -= elen + 2;
        p += elen + 2;
    }

    /* Conservative estimate. Accurate width needs detailed HT/VHT/HE operation parsing. */
    if (freq >= 2412 && freq <= 2484) return has_ht ? 20 : 20;
    if (has_vht || has_he) return 80;
    if (has_ht) return 40;
    return 20;
}

static int estimate_phy_rate_mbps(const char *phy_mode, int width, int signal_dbm) {
    int rate = 54;
    if (strstr(phy_mode, "Wi-Fi 7")) rate = (width >= 160) ? 2400 : 1200;
    else if (strstr(phy_mode, "Wi-Fi 6")) rate = (width >= 80) ? 1201 : 574;
    else if (strstr(phy_mode, "Wi-Fi 5")) rate = (width >= 80) ? 866 : 433;
    else if (strstr(phy_mode, "Wi-Fi 4")) rate = (width >= 40) ? 300 : 150;
    else rate = 54;

    if (signal_dbm < -80) rate /= 4;
    else if (signal_dbm < -70) rate /= 2;
    return rate < 1 ? 1 : rate;
}

static int callback_trigger(struct nl_msg *msg, void *arg) {
    struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
    struct trigger_results *results = arg;

    if (gnlh->cmd == NL80211_CMD_SCAN_ABORTED) {
        results->done = 1;
        results->aborted = 1;
    } else if (gnlh->cmd == NL80211_CMD_NEW_SCAN_RESULTS) {
        results->done = 1;
        results->aborted = 0;
    }
    return NL_SKIP;
}

static int callback_dump(struct nl_msg *msg, void *arg) {
    struct genlmsghdr *gnlh = nlmsg_data(nlmsg_hdr(msg));
    struct nlattr *tb[NL80211_ATTR_MAX + 1];
    struct nlattr *bss[NL80211_BSS_MAX + 1];

    static struct nla_policy bss_policy[NL80211_BSS_MAX + 1] = {
        [NL80211_BSS_FREQUENCY] = {.type = NLA_U32},
        [NL80211_BSS_BSSID] = {},
        [NL80211_BSS_INFORMATION_ELEMENTS] = {},
        [NL80211_BSS_SIGNAL_MBM] = {.type = NLA_U32},
        [NL80211_BSS_SEEN_MS_AGO] = {.type = NLA_U32},
        [NL80211_BSS_STATUS] = {.type = NLA_U32},
    };

    nla_parse(tb, NL80211_ATTR_MAX, genlmsg_attrdata(gnlh, 0), genlmsg_attrlen(gnlh, 0), NULL);
    if (!tb[NL80211_ATTR_BSS]) return NL_SKIP;
    if (nla_parse_nested(bss, NL80211_BSS_MAX, tb[NL80211_ATTR_BSS], bss_policy)) return NL_SKIP;
    if (!bss[NL80211_BSS_BSSID] || !bss[NL80211_BSS_INFORMATION_ELEMENTS]) return NL_SKIP;
    if (result_count >= MAX_RESULTS) return NL_SKIP;

    struct wifi_data *r = &dataResult[result_count];
    memset(r, 0, sizeof(*r));
    r->frequency = 0;
    r->channel = -1;
    r->channel_width_mhz = 20;
    r->mbm = 0;
    r->signal_dbm = -100;
    r->signal_quality = 0;
    r->connected = 0;
    r->channel_utilization = -1;
    r->seen_ms_ago = -1;
    strcpy(r->band, "unknown");
    strcpy(r->vendor, "Unknown");
    strcpy(r->phy_mode, "Unknown");
    strcpy(r->security, "Unknown");

    if (bss[NL80211_BSS_FREQUENCY]) {
        r->frequency = nla_get_u32(bss[NL80211_BSS_FREQUENCY]);
        r->channel = freq_to_channel(r->frequency);
        snprintf(r->band, sizeof(r->band), "%s", freq_to_band(r->frequency));
    }

    get_bssid(r->bssid, nla_data(bss[NL80211_BSS_BSSID]));
    get_vendor(r->vendor, sizeof(r->vendor), r->bssid);

    const unsigned char *ie = nla_data(bss[NL80211_BSS_INFORMATION_ELEMENTS]);
    int ielen = nla_len(bss[NL80211_BSS_INFORMATION_ELEMENTS]);
    get_ssid(r->ssid, ie, ielen);
    parse_security(r->security, ie, ielen);
    parse_phy_mode(r->phy_mode, sizeof(r->phy_mode), ie, ielen);
    r->channel_utilization = parse_channel_utilization(ie, ielen);
    r->channel_width_mhz = estimate_channel_width_mhz(ie, ielen, r->frequency);

    if (bss[NL80211_BSS_SIGNAL_MBM]) {
        r->mbm = (int32_t)nla_get_u32(bss[NL80211_BSS_SIGNAL_MBM]);
        r->signal_dbm = r->mbm / 100;
        r->signal_quality = signal_quality_from_dbm(r->signal_dbm);
    }

    if (bss[NL80211_BSS_STATUS]) {
        uint32_t status = nla_get_u32(bss[NL80211_BSS_STATUS]);
        r->connected = (status == NL80211_BSS_STATUS_ASSOCIATED || status == NL80211_BSS_STATUS_AUTHENTICATED || status == NL80211_BSS_STATUS_IBSS_JOINED) ? 1 : 0;
    }

    if (bss[NL80211_BSS_SEEN_MS_AGO]) r->seen_ms_ago = nla_get_u32(bss[NL80211_BSS_SEEN_MS_AGO]);
    r->max_phy_rate_mbps = estimate_phy_rate_mbps(r->phy_mode, r->channel_width_mhz, r->signal_dbm);

    result_count++;
    return NL_SKIP;
}

static int do_scan_trigger(struct nl_sock *socket, int if_index, int driver_id) {
    struct trigger_results results = {.done = 0, .aborted = 0};
    struct nl_msg *msg;
    struct nl_cb *cb;
    struct nl_msg *ssids_to_scan;
    int err;
    int ret;
    int mcid = genl_ctrl_resolve_grp(socket, "nl80211", "scan");

    if (mcid >= 0) nl_socket_add_membership(socket, mcid);
    msg = nlmsg_alloc();
    if (!msg) return -ENOMEM;
    ssids_to_scan = nlmsg_alloc();
    if (!ssids_to_scan) {
        nlmsg_free(msg);
        return -ENOMEM;
    }
    cb = nl_cb_alloc(NL_CB_DEFAULT);
    if (!cb) {
        nlmsg_free(msg);
        nlmsg_free(ssids_to_scan);
        return -ENOMEM;
    }

    genlmsg_put(msg, 0, 0, driver_id, 0, 0, NL80211_CMD_TRIGGER_SCAN, 0);
    nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_index);
    nla_put_u32(msg, NL80211_ATTR_SCAN_FLAGS, NL80211_SCAN_FLAG_FLUSH);
    nla_put(ssids_to_scan, 1, 0, "");
    nla_put_nested(msg, NL80211_ATTR_SCAN_SSIDS, ssids_to_scan);
    nlmsg_free(ssids_to_scan);

    nl_cb_set(cb, NL_CB_VALID, NL_CB_CUSTOM, callback_trigger, &results);
    nl_cb_err(cb, NL_CB_CUSTOM, error_handler, &err);
    nl_cb_set(cb, NL_CB_FINISH, NL_CB_CUSTOM, finish_handler, &err);
    nl_cb_set(cb, NL_CB_ACK, NL_CB_CUSTOM, ack_handler, &err);
    nl_cb_set(cb, NL_CB_SEQ_CHECK, NL_CB_CUSTOM, no_seq_check, NULL);

    err = 1;
    ret = nl_send_auto(socket, msg);
    if (ret < 0) {
        nlmsg_free(msg);
        nl_cb_put(cb);
        return ret;
    }
    while (err > 0) ret = nl_recvmsgs(socket, cb);
    if (ret < 0) {
        nlmsg_free(msg);
        nl_cb_put(cb);
        return ret;
    }
    while (!results.done) nl_recvmsgs(socket, cb);

    nlmsg_free(msg);
    nl_cb_put(cb);
    if (mcid >= 0) nl_socket_drop_membership(socket, mcid);
    return results.aborted ? 1 : 0;
}

static void perform_scan(struct nl_sock *socket, int if_index, int driver_id) {
    result_count = 0;
    struct nl_msg *msg = nlmsg_alloc();
    if (!msg) return;

    genlmsg_put(msg, 0, 0, driver_id, 0, NLM_F_DUMP, NL80211_CMD_GET_SCAN, 0);
    nla_put_u32(msg, NL80211_ATTR_IFINDEX, if_index);
    nl_socket_modify_cb(socket, NL_CB_VALID, NL_CB_CUSTOM, callback_dump, NULL);

    int ret = nl_send_auto(socket, msg);
    if (ret >= 0) nl_recvmsgs_default(socket);
    nlmsg_free(msg);
}

static void metrics(void) {
    printf("{\"metrics\":[");
    for (int i = 0; i < result_count; i++) {
        char ssid[80], bssid[40], security[96], vendor[96], phy_mode[96], band[16];
        json_escape(dataResult[i].ssid, ssid, sizeof(ssid));
        json_escape(dataResult[i].bssid, bssid, sizeof(bssid));
        json_escape(dataResult[i].security, security, sizeof(security));
        json_escape(dataResult[i].vendor, vendor, sizeof(vendor));
        json_escape(dataResult[i].phy_mode, phy_mode, sizeof(phy_mode));
        json_escape(dataResult[i].band, band, sizeof(band));

        if (i > 0) printf(",");
        printf(
            "{\"name\":\"beacon_wifi_scan_signal_dbm\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\",\"frequency\":\"%d\",\"width\":\"%d\",\"security\":\"%s\",\"vendor\":\"%s\",\"phy_mode\":\"%s\"}},"
            "{\"name\":\"beacon_wifi_scan_signal_quality_percent\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\",\"frequency\":\"%d\",\"width\":\"%d\",\"security\":\"%s\",\"vendor\":\"%s\",\"phy_mode\":\"%s\"}},"
            "{\"name\":\"beacon_wifi_scan_frequency_mhz\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\"}},"
            "{\"name\":\"beacon_wifi_scan_channel\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"width\":\"%d\"}},"
            "{\"name\":\"beacon_wifi_scan_channel_width_mhz\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\"}},"
            "{\"name\":\"beacon_wifi_scan_connected\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\"}},"
            "{\"name\":\"beacon_wifi_scan_channel_utilization_percent\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\"}},"
            "{\"name\":\"beacon_wifi_scan_phy_rate_mbps\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\",\"phy_mode\":\"%s\"}},"
            "{\"name\":\"beacon_wifi_scan_seen_ms_ago\",\"kind\":\"gauge\",\"value\":%d,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\"}},"
            "{\"name\":\"beacon_wifi_scan_ap_info\",\"kind\":\"gauge\",\"value\":1,\"labels\":{\"ssid\":\"%s\",\"bssid\":\"%s\",\"band\":\"%s\",\"channel\":\"%d\",\"frequency\":\"%d\",\"width\":\"%d\",\"security\":\"%s\",\"vendor\":\"%s\",\"phy_mode\":\"%s\"}}",
            dataResult[i].signal_dbm, ssid, bssid, band, dataResult[i].channel, dataResult[i].frequency, dataResult[i].channel_width_mhz, security, vendor, phy_mode,
            dataResult[i].signal_quality, ssid, bssid, band, dataResult[i].channel, dataResult[i].frequency, dataResult[i].channel_width_mhz, security, vendor, phy_mode,
            dataResult[i].frequency, ssid, bssid, band, dataResult[i].channel,
            dataResult[i].channel, ssid, bssid, band, dataResult[i].channel_width_mhz,
            dataResult[i].channel_width_mhz, ssid, bssid, band, dataResult[i].channel,
            dataResult[i].connected, ssid, bssid, band, dataResult[i].channel,
            dataResult[i].channel_utilization, ssid, bssid, band, dataResult[i].channel,
            dataResult[i].max_phy_rate_mbps, ssid, bssid, band, dataResult[i].channel, phy_mode,
            dataResult[i].seen_ms_ago, ssid, bssid, band, dataResult[i].channel,
            ssid, bssid, band, dataResult[i].channel, dataResult[i].frequency, dataResult[i].channel_width_mhz, security, vendor, phy_mode
        );
    }
    printf("]}\n");
}

/* An interface is wireless if /sys/class/net/<name>/phy80211 exists. */
static int is_wireless_iface(const char *name) {
    char path[300];
    snprintf(path, sizeof(path), "/sys/class/net/%s/phy80211", name);
    return access(path, F_OK) == 0;
}

/* Pick the first wireless interface; returns 1 and fills out on success. */
static int find_wireless_iface(char *out, size_t out_size) {
    DIR *d = opendir("/sys/class/net");
    if (!d) return 0;
    struct dirent *e;
    int found = 0;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.') continue;
        if (is_wireless_iface(e->d_name)) {
            snprintf(out, out_size, "%s", e->d_name);
            found = 1;
            break;
        }
    }
    closedir(d);
    return found;
}

int main(int argc, char **argv) {
    char iface_buf[64];
    const char *iface = NULL;

    /* Explicit interface argument wins; otherwise auto-detect (wlan0, wlp3s0, ...). */
    if (argc > 1 && argv[1] && argv[1][0] != '\0' && if_nametoindex(argv[1]) != 0) {
        iface = argv[1];
    } else if (find_wireless_iface(iface_buf, sizeof(iface_buf))) {
        iface = iface_buf;
    } else if (if_nametoindex("wlan0") != 0) {
        iface = "wlan0";
    }

    if (!iface) {
        printf("{\"metrics\":[]}\n");
        return 0;
    }

    int if_index = if_nametoindex(iface);
    if (if_index == 0) {
        printf("{\"metrics\":[]}\n");
        return 0;
    }

    struct nl_sock *socket = nl_socket_alloc();
    if (!socket) {
        printf("{\"metrics\":[]}\n");
        return 0;
    }
    if (genl_connect(socket) != 0) {
        nl_socket_free(socket);
        printf("{\"metrics\":[]}\n");
        return 0;
    }

    int driver_id = genl_ctrl_resolve(socket, "nl80211");
    if (driver_id < 0) {
        nl_socket_free(socket);
        printf("{\"metrics\":[]}\n");
        return 0;
    }

    if (do_scan_trigger(socket, if_index, driver_id) != 0) {
        nl_socket_free(socket);
        printf("{\"metrics\":[]}\n");
        return 0;
    }

    perform_scan(socket, if_index, driver_id);
    metrics();
    nl_socket_free(socket);
    return 0;
}
